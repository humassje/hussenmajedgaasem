<?php

include "kill.php";
global $connect;
mysqli_set_charset( $connect, 'utf8');





@$GetInfo = "SELECT * FROM `info_user` WHERE user_token = $_COOKIE[tokenuser] ";
@$RunInfo = mysqli_query($connect, $GetInfo);
@$RowInfo = mysqli_fetch_array($RunInfo);

@$imgshoss = $RowInfo['img_path'];
@$adress = $RowInfo['user_birth'];
@$phone = $RowInfo['user_pass'];

@$size = $RowInfo['user_name'];


echo $imgshoss;


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battls</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <header>
        <div class="bagtitel">
            <h1 class="texttitel">تتبع الطلب</h1>
        </div>
    </header>

    <img src="assets/img/<?php echo $imgshoss ?>" alt="" class="imgtraking">



    <div class="boxorder">
        <h1 class="titelbox">تفاصيل الطلب</h1>
        <p class="adress"> العنون:<?php echo $adress;  ?></p>
        <p class="number">  <?php  echo $phone; ?>:رقم الهاتف</p>
        <p class="pricesho">    :السعر شامل التوصيل</p>
        <p>  <?php  echo $size;  ?>:الحجم </p>
    </div>


    <img src="assets/img/icons8-delivery.gif" alt="" class="carshooping">
    <div style="background: #000000;" class="fontshooping"></div>
    <img src="assets/img/icons8-user.gif" alt="" class="imgusershooping">
</body>

</html>