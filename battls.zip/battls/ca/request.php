<?php
header('Content-type: text/xml');
?>
<Response>
    <Dial callerId="+19034204405"><?php  echo $_POST['To'];?></Dial>
</Response>