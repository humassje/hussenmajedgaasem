<?php

    // الاتصال بقاعدة البيانات
    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

    $inputpost01 = @$_POST['price1'];
    
    //جلب بيانات المستخدم من قاعدة البيانات
    $TokenUrl = mysqli_real_escape_string($connect, $_GET['T']);
    $GetInfo = "SELECT * FROM setting WHERE setting_token = '2412412489'";
    $RunInfo = mysqli_query($connect, $GetInfo);
    $RowInfo = mysqli_fetch_array($RunInfo);
    $shoss = $RowInfo[$TokenUrl];
    $price = $RowInfo['price'];
    
    // تحديث بيانات المستخدم
    if(isset($_POST['input04'])){
        $Updatainfo = "UPDATE setting SET 
            price = '$inputpost01'
            
           WHERE  setting_token = '2412412489'
           
        ";
        if (mysqli_query($connect, $Updatainfo)) {
            echo'<meta http-equiv="refresh" content="0; url=editadmin.php">';
            die();
        } else {
            echo '
                    <p>لم يتم الحفظ</p>
                    <p>رقم الخطأ :  o237u5421</p>
            ';
            die();
        }
        mysqli_close($connect);
    }












    ///////////////////////////////////////////////////////
    @$u_img2 = $_FILES['show_img2']['name'];
    @$u_img_tmp2 = $_FILES['show_img2']['tmp_name'];
    @$target_dir = "assets/img/"; // مسار الصورة
   @ $target_file = $target_dir . basename($_FILES["show_img2"]["name"]); //img/556.png 
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION)); //lower png size and read
    $uploadOk = 1; // شرط تم رفع الصورة او لا من اجل الحماية 
   @ $newimgproblem = uniqid('shoss-', true).'.' . strtolower(pathinfo($_FILES['show_img2']['name'], PATHINFO_EXTENSION)); // تغيير اسم الصورة
   

    if(isset($_POST['input05'])){
        // اذا كان امتداد الصورة فارغ
        if(empty($u_img2)){
            echo'<p>2لم يتم التغيير</p><p>الرجاء اضافة مرفق</p>'; // اظهار رسالة الخطاء
            $uploadOk = 0; // تغيير القيمة الى 0 من اجل عدم السماح برفع الفايل
            echo'<meta http-equiv="refresh" content="5; url=edit.php?T='; echo $TokenUrl; echo '">'; // تحديث الصفحة
            exit;
        }else {
            # Allow certain file formats.
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" && $imageFileType != "pdf") {
                echo' <p>الامتداد المسموح به</p> <p>JPG, JPEG, PNG , GIF , PDF</p>';
                $uploadOk = 0; // تغيير القيمة الى 0 من اجل عدم السماح برفع الفايل
                echo'<meta http-equiv="refresh" content="5; url=edit.php?T='; echo $TokenUrl; echo '">';// تحديث الصفحة
                exit;
            }
          
            if($uploadOk == 0) {
                echo' <p>لم يتم التغيير</p> <p>الرجاء اضافة مرفق</p>';
                echo'<meta http-equiv="refresh" content="5; url=edit.php?T='; echo $TokenUrl; echo '">';// تحديث الصفحة
                exit;
            }

            if ($uploadOk == 1) {
                move_uploaded_file($u_img_tmp2,"assets/img/$newimgproblem"); // حفظ الصورة الى السيرفر
                if ($_FILES["u_img"]["size"] > 5000) {
                    # IF Image png type.
                    if($imageFileType == "png"){
                        # Read images to Resize it.
                        function aborahaf($filename,$percent){
                            list($width, $height) = getimagesize($filename);
                            $newwidth = $width * $percent;
                            $newheight = $height * $percent;
                            $thumb = imagecreatetruecolor($newwidth, $newheight);
                            $source = imagecreatefrompng($filename);
                            // preserve transparency START
                            imagecolortransparent($thumb, imagecolorallocatealpha($thumb, 0, 0, 0, 127));
                            imagealphablending($thumb, false);
                            imagesavealpha($thumb, true);
                            // preserve transparency end
                            imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
                            imagepng($thumb, $filename);
                        }
                        aborahaf("assets/img/$newimgproblem", 0.5); // حفظ الصورة الى المسار مع الاحتافظ بالجودة مع تقليل الحجم
                    }
                    # IF Image gif type.
                    if($imageFileType == "gif"){
                        # Read images to Resize it.
                        function aborahaf($filename,$percent){
                            list($width, $height) = getimagesize($filename);
                            $newwidth = $width * $percent;
                            $newheight = $height * $percent;
                            $thumb = imagecreatetruecolor($newwidth, $newheight);
                            $source = imagecreatefromgif($filename);
                            // preserve transparency START
                            imagecolortransparent($thumb, imagecolorallocatealpha($thumb, 0, 0, 0, 127));
                            imagealphablending($thumb, false);
                            imagesavealpha($thumb, true);
                            // preserve transparency end
                            imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
                            imagegif($thumb, $filename);
                        }
                        aborahaf("assets/img/$newimgproblem", 0.5);// حفظ الصورة الى المسار مع الاحتافظ بالجودة مع تقليل الحجم
                    }
                    # IF Image jpg type or jpeg type.
                    if($imageFileType == "jpg" || $imageFileType == "jpeg"){
                        # Read images to Resize it.
                        function aborahaf($filename,$percent){
                            list($width, $height) = getimagesize($filename);
                            $newwidth = $width * $percent;
                            $newheight = $height * $percent;
                            $thumb = imagecreatetruecolor($newwidth, $newheight);
                            $source = imagecreatefromjpeg($filename);
                            imagecopyresized($thumb, $source, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
                            imagejpeg($thumb, $filename);
                        }
                        aborahaf("assets/img/$newimgproblem", 0.1);// حفظ الصورة الى المسار مع الاحتافظ بالجودة مع تقليل الحجم
                    }
                }
                $updateinfo = "UPDATE setting SET $TokenUrl = '$newimgproblem' WHERE setting_token = '2412412489' "; //حفظ داتا بيس
            }
            if(mysqli_query($connect, $updateinfo)){
                echo'<meta http-equiv="refresh" content="0; url=editadmin.php?T='.$TokenUrl.'">';
                exit;
            }
            else {
                echo'<p>لم يتم التغيير</p> <p>الرجاء اضافة صورة</p>';
                echo'<meta http-equiv="refresh" content="5; url=editadmin.php?T=$TokenUrl ">';
                exit;
            }
        }
    }
    
   

?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل بيانات المستخدمين</title>
</head>
<body>

    <style>
        .style01{
            text-align: center;
            font-size: large;
            font-weight: bold;
            font-family: auto;
        }
    </style>

    <form action="" method="post" enctype="multipart/form-data">
        <div class="style01">
            <div>
                <p>السعر المنتج  </p>
                <input value="<?php echo $price;?>" type="text" name="price1" class="" autocomplete="off"/>
            </div>
            <div>
             
            <img src="assets/img/<?php echo $shoss; ?>"  height="200" width="200" onerror="this.onerror=null;this.src='img/img_user.png';"/>
            <br/>
            <label class="style51">
                اختر المرفق<input value="" type="file" name="show_img2" />
            </label>
            <input type="submit" name="input05" value="تغير المنتج"/>
            
            <div>
                <input type="submit" name="input04" value="تعديل بيانات  المنتج"/>
            </div>
            <div>
                <a href="adminshoss.php"><p>الرجوع</p></a>




            </div>
        </div>
    </form>





</body>
</html>