<?php
     
     

    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

 
 


  
  @$GetInfo = "SELECT * FROM setting WHERE setting_token = '2412412489'";
  @$RunInfo = mysqli_query($connect, $GetInfo);
  @$RowInfo = mysqli_fetch_array($RunInfo);
  @$shoss1 = $RowInfo['shos1'];
  @$shoss2 = $RowInfo['shos2'];
  @$shoss3 = $RowInfo['shos3'];
  @$shoss4 = $RowInfo['shos4'];
  @$shoss5 = $RowInfo['shos5'];
  @$shoss7 = $RowInfo['shos7'];
  

  @$price = $RowInfo['price'];
  
    @  $TokenUrl = mysqli_real_escape_string($connect, $_GET['T']);
    
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battls</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <header>
        <div class="bagtitel">
            <h1 class="texttitel">تعديل المنتجات</h1>
        </div>
    </header>

    <a href="editadmin.php?T=shos1">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 190px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">


        <img class="imgadmin" src="assets/img/<?php  echo $shoss1;  ?>" alt="">



    </div>
</a>

<a href="editadmin.php?T=shos2">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 393px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">


        <img src="assets/img/<?php  echo  $shoss2 ?>" alt="" class="imgadmin">



    </div>
</a>
    <br>




    <a href="editadmin.php?T=shos3">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 597px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">


        <img src="assets/img/<?php echo $shoss3;  ?>" alt="" class="imgadmin">


    </div>
</a>


<a href="editadmin.php?T=shos4">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 799px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">
        <img src="assets/img/<?php echo $shoss4  ?>" alt="" class="imgadmin">
    </div>
</a>

<a href="editadmin.php?T=shos5">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 1002px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">
        <img src="assets/img/<?php echo $shoss5 ?>" alt="" class="imgadmin">

    </div>
</a>


<a href="editadmin.php?T=shos7">
    <div style="position: absolute;
width: 381px;
height: 176px;
left: 25px;
top: 1205px;

background: #FFFFFF;
border: 1px solid #E2E2E2;
box-sizing: border-box;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 38px;">
        <img src="assets/img/<?php    echo $shoss7  ?>" alt="" class="imgadmin">


    </div>

</a>








</body>

</html>