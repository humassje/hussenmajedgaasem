<?php

    // الاتصال بقاعدة البيانات
    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

    $inputpost01 = @$_POST['input01'];
    $inputpost02 = @$_POST['input02'];
    $inputpost03 = @$_POST['input03'];

    //جلب بيانات المستخدم من قاعدة البيانات
    $TokenUrl = mysqli_real_escape_string($connect, $_GET['T']);
    $GetInfo = "SELECT * FROM info_user WHERE user_token = '$TokenUrl'";
    $RunInfo = mysqli_query($connect, $GetInfo);
    $RowInfo = mysqli_fetch_array($RunInfo);
    $NameUser = $RowInfo['user_name'];
    $passworduser = $RowInfo['user_pass'];
    $birthuser = $RowInfo['user_birth'];
    $imgshoss = $RowInfo['img_path'];
    // تحديث بيانات المستخدم
    if(isset($_POST['input04'])){
        $Updatainfo = "UPDATE info_user SET
            user_name = '$inputpost01',
            user_pass = '$inputpost02',
            user_birth = '$inputpost03'
            
            WHERE user_token = '$TokenUrl'
        ";
        if (mysqli_query($connect, $Updatainfo)) {
            echo'<meta http-equiv="refresh" content="0; url=edituser.php?T='.$TokenUrl.'">';
            die();
        } else {
            echo '
                    <p>لم يتم الحفظ</p>
                    <p>رقم الخطأ :  o237u5421</p>
            ';
            die();
        }
        mysqli_close($connect);
    }





?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل بيانات المستخدمين</title>
</head>
<body>

    <style>
        .style01{
            text-align: center;
            font-size: large;
            font-weight: bold;
            font-family: auto;
        }
    </style>

    <form action="" method="post" enctype="multipart/form-data">
        <div class="style01">
            <div>
                <p>الحجم</p>
                <input value="<?php echo $NameUser ;?>" type="text" name="input01" class="" autocomplete="off"/>
            </div>
            <div>
                <p>رقم الهاتف</p>
                <input value="<?php echo $passworduser; ?>" type="text" name="input02" class="" autocomplete="off"/>
            </div>
            <div>
                <p>  عنون الزبون</p>
                <input value="<?php echo $birthuser; ?>" type="text" name="input03" class="" autocomplete="off"/>
            </div>
            <br/>
            <img src="assets/img/<?php echo $imgshoss; ?>"  height="200" width="200" onerror="this.onerror=null;this.src='img/img_user.png';"/>
            <br/>
           
            <div>
                <input type="submit" name="input04" value="تعديل بيانات  المستخدم"/>
            </div>
            <div>
                <a href="alluser.php"><p>الرجوع</p></a>




            </div>
        </div>
    </form>

<script>
    function showPosition(position) {
  let latlon = position.coords.latitude + "," + position.coords.longitude;

  let img_url = "https://maps.googleapis.com/maps/api/staticmap?center=
  "+latlon+"&zoom=14&size=400x300&sensor=false&key=YOUR_KEY";

  document.getElementById("mapholder").innerHTML = "<img src='"+img_url+"'>";
}
</script>



</body>
</html>