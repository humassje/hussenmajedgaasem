<?php

include "kill.php";
global $connect;
mysqli_set_charset( $connect, 'utf8');





$GetInfo = "SELECT * FROM `setting` ";
$RunInfo = mysqli_query($connect, $GetInfo);
$RowInfo = mysqli_fetch_array($RunInfo);
$titel = $RowInfo['insideweb'];
$shos1 = $RowInfo['shos1'];
$shos2 = $RowInfo['shos2'];
$shos3 = $RowInfo['shos3'];
$shos4 = $RowInfo['shos4'];
$shos3 = $RowInfo['shos3'];
$shos4 = $RowInfo['shos4'];
$shos5 = $RowInfo['shos5'];
$shos7 = $RowInfo['shos7'];
$price = $RowInfo['price'];

echo $shos7;


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battls</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <header>
        <div class="bagtitel">
            <h1 class="texttitel"><?php  echo $titel;  ?></h1>
        </div>
    </header>



    <section>
        <div class="bag1">
            <h1 class="price">  <?php  echo $price  //price shoss  ?> </h1>
            <img src="assets/img/<?php echo $shos1  //imgshoss ?>" alt="" class="imgshoz">
            <a href="shoss.php?T=shos1">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>


        </div>
        <div class="bag2">
            <h1 class="price"><?php  echo $price  //price shoss  ?></h1>
            <img src="assets/img/<?php echo $shos2  ?>" alt="" class="imgshoz">
            <a href="shoss.php?T=shos2">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>
            </div>

        <div class="bag3">
            <img src="assets/img/<?php echo $shos3  ?>" alt="" class="imgshoz">
            <h1 class="price"><?php  echo $price  //price shoss  ?></h1>
            <a href="shoss.php?T=shos3">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>
            </div>
        <div class="bag4">
            <img src="assets/img/<?php echo $shos4  ?>" alt="" class="imgshoz">
            <h1 class="price"><?php  echo $price  //price shoss  ?></h1>
            <a href="shoss.php?T=shos4">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>
            </div>


        <div class="bag5">
            <img src="assets/img/<?php echo $shos5  ?>" alt="" class="imgshoz">
            <h1 class="price"><?php  echo $price  //price shoss  ?></h1>
            <a href="shoss.php?T=shos5">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>
            </div>
        <div class="bag59">
            <img src="assets/img/<?php echo $shos7  ?>" alt="" class="imgshoz">
            <h1 class="price"><?php  echo $price  //price shoss  ?></h1>
            <a href="shoss.php?T=shos7">
                <div class="bagbox"><img src="assets/img/iconbag.svg" alt="" class="bagimgbox"></div>
            </a>
</div>

        <br><br><br> <br><br><br>

   

    </div>

















    

</body>

</html>