<?php

    $host ="localhost";
    $username = "root";
    $pass ="root";
    $database ="hussen-majed";
    @$connect = mysqli_connect($host,$username,$pass,$database)
    or die ('حصل خطأ في اتصال البيانات');


    
?>