<?php
     
     

    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

    $GetInfo = "SELECT * FROM info_user ";
    $RunInfo = mysqli_query($connect, $GetInfo);

   @ $TokenUrl = mysqli_real_escape_string($connect, $_GET['T']);

    if(@$_GET['D'] == "D"){
        mysqli_set_charset( $connect, 'utf8');
        $GetTokenData = "SELECT * FROM info_user WHERE user_token = '$TokenUrl'";
        $RunTokenData = mysqli_query($connect, $GetTokenData);
        if(mysqli_num_rows($RunTokenData) > 0){
            $RowTokenData = mysqli_fetch_array($RunTokenData);
            $GetToken02 = $RowTokenData['user_token'];
            if($TokenUrl != $GetToken02){
                echo'<p>رقم الخطأ jkfredsf43543</p>';
                echo'<meta http-equiv="refresh" content="10; url=alluser.php">';
                exit;
            }
            else{
                global $connect;
                mysqli_set_charset( $connect, 'utf8');
                $DeleteUser = "DELETE FROM info_user WHERE user_token = '".$TokenUrl."'";
                if(mysqli_query($connect, $DeleteUser)){
                    echo'<meta http-equiv="refresh" content="0; url=alluser.php">';
                    exit;
                }else{
                    global $connect;
                    echo "حصل خطأ رقم الخطأ n2224u765 " . mysqli_error($connect);
                    echo'<meta http-equiv="refresh" content="10; url=alluser.php">';
                }
                die();
            }
        }else{
            echo'<div class="DR_FStyle22">رقم الخطأ k231aa5415</div>';
            echo'<meta http-equiv="refresh" content="10; url=alluser.php">';
            exit;
        }
    }
    
?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>بيانات المستخدمين</title>
</head>
<body>
    <style>
        .style01{
            text-align: center;
            margin: 0px auto;
            direction: rtl;
            font-size: large;
            font-family: auto;
            font-weight: bold;
        }
        .style02{
            text-align: center;
            margin: 0px auto;
        }
        .style02 tr th{
            border: 1px solid #000;
            padding: 5px;
        }
        .style02 tr th a{
            text-decoration: none;
            color: #000;
        }
    </style>
    <div class="style01">
        <table class="style02">
            <tr>
                <th>ت</th>
                <th>الحجم</th>
                <th>رقم الهاتف</th>
                <th>العنون</th>
                <th>العنون الفعلي عل الخرائط</th>
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
            <?php
                $Number = 1;
                while($Rowinfo00 = mysqli_fetch_array($RunInfo)){
                    echo'
                    <tr>
                    <th>'.$Number.'</th>
                    <th><a href="edit.php?T='.$Rowinfo00['user_token'].'">'.$Rowinfo00['user_name'].'</a></th>
                    <th><a href="edit.php?T='.$Rowinfo00['user_token'].'">'.$Rowinfo00['user_pass'].'</a></th>
                    <th><a href="edit.php?T='.$Rowinfo00['user_token'].'">'.$Rowinfo00['user_birth'].'</a></th>
                    <th><a href="edit.php?T='.$Rowinfo00['user_token'].'">'.$Rowinfo00['maps'].'</a></th>
                    
                    <th><a href="edituser.php?T='.$Rowinfo00['user_token'].'"><img src="img/566.png" height="30" width="30" /></a></th>
                    <th><a href="alluser.php?D=D&T='.$Rowinfo00['user_token'].'"><img src="img/777.png" height="30" width="30" /></a></th>
                </tr>
                          
                    ';
                    $Number++;
                };
            ?>
        </table>
        <datalist id="orderuser">
            <option>مدير</option>
            <option>مسؤول</option>
        </datalist>
    </div>
</body>
</html>