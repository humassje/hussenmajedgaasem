


<?php
  // الاتصال بقاعدة البيانات
  include "kill.php";
  global $connect;
  mysqli_set_charset( $connect, 'utf8');

 
  //جلب بيانات المستخدم من قاعدة البيانات
  
  $GetInfo = "SELECT * FROM info_user WHERE user_token = '220128075804113' ";
  $RunInfo = mysqli_query($connect, $GetInfo);
  $RowInfo = mysqli_fetch_array($RunInfo);
  $NameUser = $RowInfo['user_name'];
  $passworduser = $RowInfo['user_pass'];
  $birthuser = $RowInfo['user_phone'];
  $imguser = $RowInfo['img_path'];
  $price = $RowInfo['price'];

   
//////////////////////////////////////
  $inputpost01 = $_POST['input01']; //size
 $inputpost02 = $_POST['input02']; //phone
 $inputpost03 = $_POST['input03']; //adress1



 $Token = @date("ymdhis");
 $RandomNumber = rand(100,200);
 $NewToken = $Token . $RandomNumber;


 if(isset($_POST['input05'])){
        
     $InsertNewName = " INSERT INTO info_user
     (
         user_token,
         user_name,
         user_pass,
         user_phone
         
     ) VALUES
     (
         '$NewToken',
         '$inputpost01',
         '$inputpost02',
         '$inputpost03'
       
     )";

     if(mysqli_query($connect, $InsertNewName)){
         echo' يا اللللللله';
         die();
     }else{
         echo 'هناك خطأ ما يرجى اعادة ادخال البيانات ^_^ ';
         die();
     }
 }
 


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $NameUser ?></title>
</head>
<body>
<form action="" method="post">

<input name="input01"    type="text">
<input  name="input02"  type="text" class="name">
<input   name="input03" type="text">



<input type="submit" value="send"  name="input05"   >
<h1>ddsfdssdfdsfs<?php echo $NameUser ?></h1>

</form>

</body>
</html>

