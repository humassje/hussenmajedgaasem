<?php
    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

    $inputpost01 = $_POST['input01'];
    $inputpost02 = $_POST['input02'];
    $inputpost03 = $_POST['input03'];



    $Token = @date("ymdhis");
    $RandomNumber = rand(100,200);
    $NewToken = $Token . $RandomNumber;


    if(isset($_POST['input04'])){
            //الخطاء كان هنا ناسي هذه العلامة ' 
        $InsertNewName = "INSERT INTO info_user
        (
            user_token,
            user_name,
            user_pass,
            user_birth
        ) VALUES
        (
            '$NewToken',
            '$inputpost01',
            '$inputpost02',
            '$inputpost03'
        )";

        if(mysqli_query($connect, $InsertNewName)){
            echo'اوكي بيناتك تم حفظها ';
            die();
        }else{
            echo 'هناك خطأ ما يرجى اعادة ادخال البيانات ^_^ ';
            die();
        }
    }
    

?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل المستخدمين</title>
</head>
<body>

    <style>
        .style01{
            text-align: center;
            font-size: large;
            font-weight: bold;
            font-family: auto;
        }
    </style>

<form action="" method="post">
        <div class="style01">
            <div>
                <p>اسم المستخدم</p>
                <input type="text" name="input01" class="" autocomplete="off"/>
            </div>
            <div>
                <p>كلمة السر </p>
                <input type="password" name="input02" class="" autocomplete="off"/>
            </div>
            <div>
                <p>مواليد المستخدم</p>
                <input type="text" name="input03" class="" autocomplete="off"/>
            </div>
            <div>
                <input type="submit" name="input04" value="اضافة مستخدم"/>
            </div>
        </div>
    </form>

</body>
</html>