<?php
    include "kill.php";
    global $connect;
    mysqli_set_charset( $connect, 'utf8');

    
    $inputsize = @$_POST['size']; //size
    $inputphone = @$_POST['phone']; //phone
    $inputpadress = @$_POST['adress'];  //adress1
    $inputmaps = @$_POST['maps']; //adress2
    $inputimg = @$_POST['imgshozz'];
    
    
$GetInfo = "SELECT * FROM `setting` ";
$RunInfo = mysqli_query($connect, $GetInfo);
$RowInfo = mysqli_fetch_array($RunInfo);
$titel = $RowInfo['insideweb'];
$shos3 = $RowInfo['shos3'];
    

    $Token = @date("ymdhis");
    $RandomNumber = rand(100,200);
    $NewToken = $Token . $RandomNumber;


    if(isset($_POST['input04'])){
            //الخطاء كان هنا ناسي هذه العلامة ' 
        $InsertNewName = "INSERT INTO `info_user`
        
        (`maps`,  `user_token`, `user_name`, `user_pass`, `user_birth`, `img_path`) 
        VALUES 
        ('$inputmaps','$NewToken','$inputsize','$inputphone','$inputpadress','$inputimg');
       
        ";

    @$user_token = $Row_selectUsers['user_token'];
        @$user_name = $Row_selectUsers['user_name'];
        
        if(mysqli_query($connect, $InsertNewName)){


          setcookie("imgshoss", $inputimg, time()+2246400); 
          setcookie("tokenuser", $NewToken, time()+2246400);


            echo "hi ";
            die();
        }else{
            echo 'هناك خطأ ما يرجى اعادة ادخال البيانات ^_^ ';
            
        }
    }
       
       

    

?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>battls</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body  onload="getLocation()"  >
  <header>
    <div class="bagtitel">
        <h1 class="texttitel"     > 4 تفاصيل</h1>
    </div>
</header>
 
<div>
  <img src="assets/img/<?php  echo $shos3  ?>" alt="" class="chkedimg">
</div>
 


     




<form action="" method="post">

<input type="text" name="maps" id="demo" class="" placeholder=" " value="j"   >

<div class="shoping">
  <select name="size" id="" class="sizeshoping"  >
    <option value=""><li class="stylesiz"  >الحجم</li></option>
    <option value="38">38</option>
    <option value="39">39</option>
    <option value="40">40</option>
    <option value="41">41</option>
    <option  value="42">42</option>
    <option value="43">43</option>
    <option value="44">44</option>
  </select>
  <input type="text" name="imgshozz" id=""  value="<?php  echo $shos3  ?>"  >
  <input type="number" name="phone" id="" class="phone" placeholder="رقم الهاتف" value="j"   >
  
    
    
    <select name="adress" id="" class="adrres1"  >
    <option value="المحافضه">المحافضه</option>
  </select>
  <select name="input05" id="" class="adrres2">
    <option  value="">المدينه،الحي</option>
  </select>






 
  <input name="input04"  type="submit" value="  متابعة الشراء" class="send"   >


  </form>


 
 

<script>


     alert= "hussen"


        const x = document.getElementById("demo");

        function getLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(showPosition);
            } else {
                x.value = "Geolocation is not supported by this browser.";
            }
        }

        function showPosition(position) {
            x.value = "Latitude: " + position.coords.latitude +
                "<br>Longitude: " + position.coords.longitude;
        }
    </script>
  

</div>
</body>
</html>










