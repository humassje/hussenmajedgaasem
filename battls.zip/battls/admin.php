<?php


include "kill.php";
global $connect;
mysqli_set_charset( $connect, 'utf8');






?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Battls</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <header>
        <div class="bagtitel">
            <h1 class="texttitel">ademin</h1>
        </div>
    </header>


<a href="adminshoss.php">
    <div class="box1admin">
        <div class="boxadmin">
            <img class="imgboxadmin" src="img/566.png" alt="">
        </div>
        <p class="textboxadmin">تعديل المنتجات</p>
    </div>
</a>

<a href="alluser.php">
    <div class="box2admin">
        <div class="boxadmin">
            <img class="imgboxadmin" src="img/icons8-logistics-64.png" alt="">
        </div>
        <p class="textboxadmin">الطلبات</p>
    </div>
</a>
    <div class="box3admin">
        <div class="boxadmin">
            <img class="imgboxadmin" src="img/icons8-marketing-plan-68.png" alt="">
        </div>
        <p class="textboxadmin">الخطة التسويقية</p>
    </div>

    <div class="box4admin">
        <div class="boxadmin">
            <img class="imgboxadmin" src="img/icons8-money.gif" alt="">
        </div>
        <p class="textboxadmin">صافي الربح </p>
    </div>

    <div class="box5admin">
        <div class="boxadmin">
            <img class="imgboxadmin" src="img/icons8-logistics-64.png" alt="">
        </div>
        <p class="textboxadmin">الكمية المتوفرة</p>
    </div>







</body>

</html>