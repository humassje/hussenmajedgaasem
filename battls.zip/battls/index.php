<?php
  // الاتصال بقاعدة البيانات
  include "kill.php";
  global $connect;
  mysqli_set_charset( $connect, 'utf8');

 
  //جلب بيانات المستخدم من قاعدة البيانات
  
  $GetInfo = "SELECT * FROM `setting` WHERE setting_token = '2412412489' ";
  $RunInfo = mysqli_query($connect, $GetInfo);
  $RowInfo = mysqli_fetch_array($RunInfo);
  $titel = $RowInfo['setting_nameweb'];
  
  $imgindex = $RowInfo['img_index'];
  

   


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $NameUser ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <header>
        <div class="hader">
            <h1 class="titel"><?php echo $titel ?>
</h1>
        </div>
    </header>


    <div  ><img class="imgtitel" src="assets/img/<?php echo $_COOKIE['imgshoss'] ?>" alt=""></div>





    <a href="bag.php">
        <div class="pro">
            <div class="pro1">
                <div class="icon">
                    <img src="assets/img/bag.png" alt="" class="imgicon">
                </div>
                <span>سلة تسوق</span>
            </div>
    </a>




    <a href="">
        <div class="pro2">
            <div class="icon">
                <img src="assets/img/bag-her.svg" alt="" class="imgicon">
            </div>
            <span>المفضلات</span>
        </div>
    </a>



    <a href="">
        <div class="pro3">
            <div class="icon">
                <img src="assets/img/cadit.svg" alt="" class="imgicon">
            </div>
            <span class="span1">الدفع</span>

        </div>
    </a>

    <a href="triking.php">
        <div class="pro4">
            <div class="icon">
                <img src="assets/img/trak.svg" alt="" class="imgicon">
            </div>
            <span>تتبع الطلب</span>
        </div>
    </a>

    </div>
    <br>

</body>

</html>
